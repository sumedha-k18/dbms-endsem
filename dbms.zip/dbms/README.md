# DBMS Lab End-Sem — SQL-only solution (PostgreSQL)

Everything (loading, cleaning, analysis, statistics, the churn model) is plain SQL
run through `psql`. No Python, no SQLite.

## Folder layout
```
data/                      the 5 CSVs from the brief
sql/00_load_and_clean.sql  creates tables, \copy loads CSVs, builds clean tables (all data fixes)
sql/01a_daily_health.sql   Part 1(a)
sql/01b_retention.sql      Part 1(b)
sql/01c_spenders.sql       Part 1(c)
sql/01d_ads.sql            Part 1(d)
sql/02a_arpdau_deep_dive.sql  Part 2(a)
sql/03_channels.sql        Part 3 (CIs, stratified differences, MDE - all in SQL)
sql/04_churn_model.sql     Part 4 (features, risk-table model, AUC, calibration, targeting)
sql/run_all.sql            runs everything, writes results to outputs/
outputs/                   query results (.txt) + full daily tables (.csv)
REPORT.md                  readout (8 slides) + appendix with all numbers and judgement calls
```

## How to run (PostgreSQL 13+; tested on 17)
```
createdb game_analytics
cd <this folder>                      # the \copy paths are relative to here
psql -d game_analytics -f sql/run_all.sql
```
Takes about 30 seconds. Any single part can be re-run on its own once
`00_load_and_clean.sql` has run, e.g. `psql -d game_analytics -f sql/03_channels.sql`.
