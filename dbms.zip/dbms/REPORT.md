# DBMS Lab End-Sem — Player Telemetry Analysis

All analysis is done in **SQL only (PostgreSQL 17)**. Every number below comes from a query in `sql/`, and the query outputs are saved in `outputs/`. See `README.md` for how to run it.

**What I did and what I skipped (triage):** I followed the suggested priority. I did Parts 1, 2, 3, 4 and the readout (5). For Part 2 I picked question **(a)**, the ARPDAU drop. I did **not** do 2(b) (only one deep-dive was required) or **4b** (optional). What I would do with those is listed at the end.

---

# PART 5 — THE READOUT (8 slides, for the Product Director)

## Slide 1 — Summary

1. **Nothing broke. ARPDAU fell 16.5% because *who* plays changed, not because players spend less.** Every country tier's ARPDAU went *up* (+2% to +12%). Revenue per day almost **tripled** ($973 → $2,788).
2. **The change comes from a paid_video push into Tier-4 countries in March–April.** Tier 4 went from 18% to 46% of active player-days. These players are fine for their tier, but their tier spends about $0.16 per day versus $0.55 in Tier 1.
3. **Channels:** once you compare like with like (same tier and platform), paid_video players are **not worse spenders**. They do play slightly less (about 4% fewer active days in the first month). That is a real difference but too small to justify moving budget on its own.
4. **Churn:** a simple SQL scorecard finds lapsing players **2.2× better than random** in its top 10%. Whether offers pay off depends on one number we don't have: how many lapsing players an offer actually saves.
5. **Recommendation:** stop using blended ARPDAU as the health KPI. Report it **per tier (or at a fixed mix)**, and judge the Tier-4 push on **revenue per install vs cost per install**, which needs the marketing cost data.

## Slide 2 — The ARPDAU drop is a mix effect (the key chart)

Weekly ARPDAU (USD per active player-day), full weeks. Source: `02a` Q8.

```
week        Tier1  Tier2  Tier3  Tier4 | ALL   | Tier-4 share of player-days
2026-01-05  0.699  0.513  0.267  0.304 | 0.489 | 17%  ███▌
2026-01-19  0.526  0.361  0.291  0.142 | 0.366 | 17%  ███▌
2026-02-02  0.685  0.444  0.349  0.211 | 0.466 | 18%  ███▌
2026-02-16  0.486  0.291  0.295  0.120 | 0.328 | 18%  ███▋
2026-03-02  0.324  0.242  0.132  0.080 | 0.206 | 24%  ████▋
2026-03-16  0.414  0.257  0.198  0.107 | 0.240 | 33%  ██████▌
2026-03-30  0.413  0.331  0.221  0.104 | 0.239 | 40%  ████████
2026-04-13  0.560  0.348  0.214  0.140 | 0.271 | 46%  █████████▎
2026-04-20  0.752  0.509  0.272  0.197 | 0.363 | 48%  █████████▋
```
(Weeks alternate high/low because sales run every ~15 days.)

First 30 days vs last 30 days:

| Tier | Share of player-days Jan → Apr | ARPDAU Jan → Apr | Change |
|---|---|---|---|
| 1 | 34.5% → 20.5% | $0.516 → $0.552 | **+7.0%** |
| 2 | 26.1% → 15.6% | $0.372 → $0.401 | **+7.9%** |
| 3 | 21.8% → 18.0% | $0.233 → $0.260 | **+11.6%** |
| 4 | 17.6% → **45.9%** | $0.154 → $0.158 | **+2.3%** |
| **All** | | **$0.353 → $0.295** | **−16.5%** |

Decomposition of the −$0.058 change: **mix effect −$0.077** (more Tier-4 player-days), **within-tier effect +$0.018** (everyone spends a bit more). **At January's tier mix, April ARPDAU would be +7.5%.**

## Slide 3 — Where the Tier-4 players came from

New installs per month (Q3 in `02a`):

| | Jan | Feb | Mar | Apr |
|---|---|---|---|---|
| organic | 4,317 | 3,839 | 4,288 | 4,217 |
| paid_social | 3,678 | 3,544 | 3,846 | 3,686 |
| **paid_video** | 1,414 | 1,702 | **9,366** | **17,835** |
| …of which Tier 4 | 259 | 596 | 7,301 | 14,673 |

Organic and paid_social stayed flat. All of the growth is **paid_video in Tier 4 (and some Tier 3)**. So someone already decided to spend more on UA. That is relevant, because the studio's goal is to grow revenue **without** growing marketing spend.

## Slide 4 — Are paid_video players "worse"? Mostly no

30-day results for new installs from Jan–Mar (every player gets the same 30 days):

| | Raw: paid_video vs organic | Same tier & platform: paid_video vs organic |
|---|---|---|
| Revenue per install (30d) | −$0.93 (−38%), CI [−1.19, −0.67] | **−$0.16, CI [−0.48, +0.15] → not significant** |
| Payer rate (30d) | −4.3 pts | **−0.7 pts, not significant** |
| Active days in first 30 | −0.25 days | **−0.30 days (−4%), CI [−0.39, −0.22] → significant** |
| D7 retention | −1.9 pts | −1.3 pts, CI [−2.5, −0.0] → borderline |

- **Revenue gap = artefact.** paid_video is 65% Tier 4 and 80% Android, against 18% and 63% for organic. Inside each tier, paid_video installs earn about the same, and in Tier 4 slightly more ($1.12 vs $1.02).
- **Engagement gap = real but small.** About 0.3 fewer active days a month. paid_social vs paid_video on D7 (−0.9 pts) is smaller than the 1.8-point minimum effect this sample can detect, so *we cannot tell*.

## Slide 5 — Should UA move budget between channels?

- **Not on player quality.** Within tier, paid_social and paid_video differ by **$0.02 per install** (CI ±$0.32). That isn't a difference you can move budget on.
- **The decision should be made on cost.** Shift spend to channel A over B only if `CPI_A / CPI_B < value_A / value_B`. Within a tier, the value ratio is about 1.0, so **buy the cheaper install in each tier.**
- **Tier-4 installs are worth about $1.09 in their first 30 days, versus $3.46 for Tier 1.** If a Tier-4 paid_video install costs more than roughly $1.09 × (90-day/30-day multiplier), the March–April push loses money. **I need cost-per-install by channel and tier to say.**

## Slide 6 — Churn: who is about to lapse

- **Definition:** a currently active player (active in the last 7 days, installed 7+ days ago) with **no activity in the next 14 days**. About 20% of active players each week.
- **Why 14 days:** it is longer than 90% of normal gaps between play days (median gap 3 days, p90 15 days). **But it is a lapse, not a loss: 85% of them come back within the next 30 days**, though they play less. Offers will partly go to people who would have returned anyway.
- **Model:** a churn-rate lookup table learned in SQL (recency × frequency × tenure × payer × trend), tested out-of-time on the **Apr 16** week. AUC **0.69** against 0.54 for "days since last active". Predicted churn matches actual churn in every risk decile (for example, top decile 44.5% predicted vs 44.0% actual).
- **Biggest risk factors:** few active days in the last 28 (37% churn vs 5% for 11+ days), **long tenure** (90+ day players: 36%), and a recent *burst* after a quiet period.

## Slide 7 — How many offers would be wasted?

Test week (Apr 16, 32,330 active players, 20.4% lapse):

| Target the riskiest… | Offers | Hit a real lapser | Lapsers reached | Wasted offers | Break-even V/c (if offer saves 25%) |
|---|---|---|---|---|---|
| 10% | 3,233 | 44% | 22% | 1,811 | 9× |
| 20% | 6,466 | 39% | 38% | 3,974 | 10× |
| 30% | 9,699 | 35% | 52% | 6,275 | 11× |
| everyone | 32,330 | 20% | 100% | 25,739 | 20× |

**Rule:** send an offer when `p(lapse) × u × V > c`. If an offer saves 25% of lapsers (u), then **targeting the top 10% pays when a saved player is worth more than 9× the offer cost.** At u = 10% the bar is 23×. **Recommendation:** start with the top 10–20% and **hold out a random 10% of them**, so we measure u instead of guessing it.

## Slide 8 — What I'm unsure about & next steps

- **Missing inputs:** cost per install by channel and tier (decides Slides 3 and 5), the value of a retained player and the offer cost (Slide 7), and ad revenue (we only see ad *engagement*).
- **Data issues that change numbers** (details in the appendix): 122 duplicate purchases, refunds, an 8-hour clock error on ads, a 2-day ad-logging outage (Mar 5–6), and purchases with no session row.
- **Next:** (1) get CPI and test the Tier-4 push on payback; (2) run the churn offer as an A/B test with a holdout; (3) Finance's sales question (2b): I saw revenue dip in the days *before* each sale, which supports their view, but I did not finish it.

---

# APPENDIX

## A1. Data-quality issues and how I handled them

These are the ones that actually changed answers, roughly in order of impact:

1. **Install volume triples during the window (the big one).** Installs go from about 2,200 a week in Jan–Feb to about 6,500 a week by late April, almost all paid_video in Tier 4. Any number that pools players across time (ARPDAU, channel averages, "revenue per player") is confounded by this. **Handled by:** comparing within tier, measuring every install over the same 30-day horizon, and only showing retention cells that are fully matured.
2. **ad_view timestamps are 8 hours ahead of everything else.** Ads start at 14:00 on Jan 1 and end at 07:59 on May 1, while other tables run 06:00–23:59. On the raw clock, 330k of 648k ad rows fall on a day the player wasn't active. After shifting −8h, **zero** do. **Handled by:** shifting in the clean `ad_views` table, so ads are counted on the right day.
3. **Ad logging outage, Mar 5 00:00 to Mar 7 06:00 (corrected clock).** There are zero ad rows for 54 hours, while DAU is normal. This is a pipeline gap, not a real drop. **Handled by:** flagging and excluding Mar 5–6 from any ad trend. I would ask data engineering whether the events can be backfilled, and add an alert when views per DAU fall below 60% of the 7-day average (my anomaly query does exactly this).
4. **Duplicate purchases.** 122 `purchase_id`s appear twice with different timestamps, worth $1,841. **Handled by:** keeping the first row.
5. **Refunds.** 226 negative rows (−$3,250). **Handled by:** keeping them in a separate table. Gross revenue excludes them, net revenue and revenue concentration subtract them.
6. **Purchases with no `player_day` row.** 2,449 purchases (16%), about 40% of them on sale days. Counting them as revenue but not as active players would put payers outside the denominator. **Handled by:** defining an active day as a `player_day` row **or** a purchase.
7. **Linked devices** (`original_device_id`). 3,211 devices are re-installs by existing players and both devices are in the file. **Handled by:** excluding them from install cohorts and channel analysis (they are not new players), and rolling them up to one person for revenue concentration and churn (otherwise a phone change looks like churn).
8. **Smaller ones:** 110 players have a first purchase one day *before* install (install date logged late), which I clipped to day 0. Players installed before 2026 are excluded from time-to-first-purchase because their real first purchase may be before the window. `activity_date` is an integer and is converted to a date.

**Query mistakes I caught by cross-checking totals** (the brief warned about plausible-looking wrong answers):
- `GREATEST(first_purchase_date - install_date, 0)` returns **0 when the date is NULL**, which made every non-payer a "day-0 payer" (83% paying on day 0!). Fixed with a `CASE`.
- A `ROLLUP` total row was included in a window `SUM`, which halved every tier share.
- `AVG(dau)` on a ROLLUP total row averages platform-days, which gave half the real DAU.
- Postgres integer division (`COUNT/COUNT` = 0) needs `::NUMERIC`.

## A2. Part 1 numbers

### 1(a) Daily health
Full daily table: `outputs/01a_daily_health.csv` (240 rows = 120 days × 2 platforms). Whole window:

| Platform | Avg DAU | Gross revenue | Refunds | ARPDAU | Share of active players paying that day |
|---|---|---|---|---|---|
| Android | 3,831 | $113,108 | $1,631 | $0.246 | 1.68% |
| iOS | 1,751 | $104,485 | $1,619 | $0.497 | 3.44% |
| **Total** | **5,582** | **$217,593** | $3,250 | **$0.325** | 2.23% |

Checks: revenue in 1(a) = revenue in `purchases` exactly, the max daily payer share is 10.3% (on a sale day, so never > 100%), and there are 240 rows. iOS players are about 30% of DAU but bring in 48% of revenue.

### 1(b) Retention (% of the install-week cohort active on day N)

| Wk | Start | Installs | D1 | D7 | D14 | D30 |
|---|---|---|---|---|---|---|
| 0 | Jan 01 | 2,047 | 45.9 | 25.4 | 19.0 | 12.6 |
| 1 | Jan 08 | 2,173 | 48.0 | 26.6 | 19.9 | 15.4 |
| 2 | Jan 15 | 2,173 | 48.0 | 25.7 | 18.1 | 13.9 |
| 3 | Jan 22 | 2,085 | 47.5 | 26.2 | 20.0 | 13.4 |
| 4 | Jan 29 | 2,186 | 48.5 | 24.7 | 21.6 | 14.6 |
| 5 | Feb 05 | 2,163 | 47.2 | 27.8 | 20.3 | 15.3 |
| 6 | Feb 12 | 2,246 | 50.3 | 24.4 | 20.2 | 14.3 |
| 7 | Feb 19 | 2,263 | 46.2 | 25.0 | 19.9 | 14.2 |
| 8 | Feb 26 | 2,850 | 48.0 | 26.4 | 18.5 | 13.4 |
| 9 | Mar 05 | 3,340 | 47.7 | 24.8 | 19.6 | 14.2 |
| 10 | Mar 12 | 3,776 | 46.7 | 27.0 | 19.4 | 13.5 |
| 11 | Mar 19 | 4,430 | 48.8 | 24.5 | 19.5 | 13.9 |
| 12 | Mar 26 | 4,945 | 47.9 | 25.1 | 19.9 | — |
| 13 | Apr 02 | 5,468 | 47.4 | 26.9 | 18.9 | — |
| 14 | Apr 09 | 6,030 | 47.9 | 24.7 | 19.3 | — |
| 15 | Apr 16 | 6,230 | 47.8 | 24.3 | — | — |
| 16 | Apr 23 | 6,425 | 47.7 | — | — | — |
| 17 | Apr 30 | 902 | — | — | — | — |

**Rule:** a cell is filled only if the *last* player installed that week has reached day N by Apr 30. A half-matured cell would either use fewer players or count "hasn't happened yet" as churn, and both look like a fake drop. Weeks start on Jan 1, so no week is cut by the window start. Re-installs are excluded.

**Observation:** retention is flat across all cohorts, even though the March–April cohorts are mostly Tier-4 paid_video. Play is intermittent: 93% of installs come back at some point in days 1–7, but only 26% are active *exactly* on day 7. Also, only 65% are active on their install day, so install date and first session don't always match.

### 1(c) Spender behaviour
- **Revenue concentration (net of refunds, people not devices).** Among **payers only** (10,886 people): top 1% → **9.3%** of revenue, top 10% → **60.3%**, top 50% → **91.0%**. Ranking **all players** (77,196) gives 39.4% / 97.5% / 100%. That looks dramatic but only says "86% of people pay nothing". I use the payers-only version.
- **Time to first purchase.** Of Jan–Mar installs, **12.1% pay within 30 days**: 1.3% on day 0, 2.0% on days 1–3, 2.2% on days 4–7, 2.6% on days 8–14, 4.0% on days 15–30. For January installs followed for 89 days, **22.5% pay**, and 9.3% pay for the first time *after* day 30. So **77.5% never pay** in their first 3 months. Among January payers the median first purchase is on **day 22** (p25 = 7, p75 = 49). Players take weeks to convert, not a session.
- **Repeat purchase gap** (2,509 repeat buyers, 4,075 gaps, computed with `LAG()`): median **15.3 days**, p25 6.4, p75 32.9, p90 55.1, mean 22.8. The median matches the **~15-day sale cycle**, a hint that repeat buyers time their purchases to sales (relevant to 2b).

### 1(d) Rewarded ads
- `ad_daily_count` is the n-th ad interaction of that player-day. Rows with count = 1 equal the number of ad player-days exactly (392,949). The rows just aren't in time order.

| Cap | Ad player-days | % that hit the cap | % hit (completed views only) | Avg completed views |
|---|---|---|---|---|
| 5 | 294,861 | 1.27% | 0.48% | 1.35 |
| 8 | 98,088 | 0.02% | 0.00% | 1.35 |

- **Players almost never hit the cap.** Cap 5 and cap 8 days have the *same* average views (1.35). 61.5% of players saw both caps on different days, so the cap looks randomly assigned, which makes this a natural experiment: **raising the cap does not increase ad views.**
- **Daily views:** these grow with DAU (1,292 on Jan 1 to about 9,700 by late April). Views per DAU are steady and rising (0.75 → 0.85 by month), except **Mar 5–6 = 0**, which is the logging outage (A1, item 3).
- **What I'd tell the product team:** the cap is not the constraint, so don't spend effort raising it. If you want more ad engagement, look at placements and reward value. Since `reward_amount` is a cost to the game economy, extra views also need ad revenue (finance data) to be valued.

## A3. Part 2(a) details
- Both periods contain exactly **4 sale days**, so sales don't bias the comparison.
- Q4 checks for a second mix effect *inside* tiers (new vs established players). There is some, especially in Tier 4 where 77% of April player-days are from players under 30 days old, but within each tier the totals still went up.
- Q5: within Tier 4, paid_video players' ARPDAU ($0.160) equals organic ($0.160) in April. The channel isn't the problem, the geography is.
- **Business answer:** don't "fix" ARPDAU. Report it at a fixed tier mix, or report revenue per day and revenue per install. The real question is whether the March–April Tier-4 UA spend pays back. Break-even: a Tier-4 install returns about **$1.09 in 30 days** (Q7). The push is worth it only if CPI is below that times the eventual LTV/30-day multiplier. **Needs CPI data.**

## A4. Part 3 details
- **Population:** new installs Jan 1–Mar 31 (35,994), each measured over its own first 30 days.
- **Engagement:** D7 retention (active on day 7) and active days in days 0–29. **Revenue:** gross USD in days 0–29, and payer rate in days 0–29.
- **The misleading comparison:** "revenue per player over the window" for all players gives organic $3.66 vs paid_video $1.64. It mixes in 2025 installs (more time to spend) and ignores geography.
- **Adjustment method (pure SQL):** difference computed within each tier × platform stratum, weighted by stratum share. Variance = Σw²(s²ₐ/nₐ + s²ᵦ/nᵦ), and 95% CI = ±1.96·SE.
- **MDE** (80% power, 5% significance) = 2.8·SE: about **1.8 points** for D7 and about **$0.36–0.45** for 30-day revenue, which is 15–18% of the mean. The top 1% of installs carry **42.5%** of 30-day revenue, so revenue comparisons need very large samples.
- **To call a difference *real* rather than an artefact I would need:** (1) a randomised test, e.g. a geo holdout or a budget split, because channels choose their audiences; (2) clean attribution (4% of each channel's "installs" are re-installs of existing players, and organic may include people who saw an ad); (3) a longer horizon (90-day revenue); (4) CPI to judge value for money.

## A5. Part 4 details
- **Setup:** weekly snapshots. Train on Jan 29–Mar 19 (8 snapshots, 128k rows), validate on Apr 2 (26k), test on Apr 16 (32k). The split is **out-of-time** because the model will score future weeks, and the player mix is changing fast. Random splitting would leak the same person-week patterns across sets. Label windows don't overlap across sets.
- **Features (all known at snapshot time):** days since last active, active days in the last 7, prior 7 and last 28, tenure, payer before, plus platform, tier and channel for segment checks.
- **Model:** a smoothed risk table with 288 cells (recency × frequency × tenure × payer × trend). Each cell's training churn rate is shrunk towards its recency × frequency parent: `(churners + K·parent_rate)/(n + K)`. K was picked on validation (5 and 25 tie at 0.687, and I use 25). Without the extra dimensions (K → ∞) AUC drops to 0.650, so tenure, payer and trend add real information. I used this instead of logistic regression because it can be built and read entirely in SQL, and each cell is just "churn rate of players like this".
- **Metrics:** AUC (ranking quality, computed with the rank formula), Brier score (probability accuracy; 0.149 vs 0.162 when always predicting the base rate), calibration by decile, and precision/recall at targeting depths. **What they don't tell you:** whether an offer *changes* behaviour. A good churn model can still pick people an offer can't save, or who would return anyway (85% do within 30 days).
- **Where it works badly:** **within a tenure band** the AUC is only 0.59–0.63, so much of the power comes from "old players lapse more". It is also weaker for paid_video/Tier 4 (0.66) than organic (0.70). Most of those players are new and we have little history on them.
- **Threshold:** the profitable depth is where `p × u × V = c`. See Slide 7. Without V, c and u, I recommend the top 10–20% plus a holdout.

## A6. Dead ends and what I'd do with another week
- **2(b) sales (not done).** From the 1(a) data: sales are 2-day events every ~15 days (Jan 8–9, Jan 23–24, … Apr 23–24). Revenue on non-sale days drops in the 3–4 days *before* each sale (for example Apr 19–22 ≈ $1,000/day vs $3,000/day on Apr 16–18). The median repeat-purchase gap of 15.3 days equals the cycle. Both support Finance's "timing shift" argument. I would measure total revenue per 15-day cycle per active player against sale depth, and propose randomising sale timing by region to settle it.
- **4b (not done).** The hard part is labels: a 90-day label needs installs before Jan 31, only about 9.4k players, and all from the *old* Jan mix. A model trained on them would be applied to a very different Tier-4 paid_video population.
- **Dead end:** I first defined churn as "never comes back", but with 120 days of data and 79% of even 28-day-quiet players returning, that can't be labelled properly. I switched to a 14-day lapse.
- **Dead end:** I tried using `ad_daily_count` as a running counter in time order. It doesn't increase with the timestamp, so I used the max per day instead.
- **With more time:** an ad-reward economy analysis (`currency_spend` is barely used here), D30 by channel once April cohorts mature, and a logistic regression to compare with the risk table.
